import psycopg2
from psycopg2 import Error

try:
    connection = psycopg2.connect(
        user="postgres",
        password="1111",
        host="127.0.0.1",
        port="5432",
        database="postgres_db"
    )
    cursor = connection.cursor()
    postgresql_select_query = "SELECT * FROM mobile"
    cursor.execute(postgresql_select_query)

    print("Вывод двух строк")
    mobile_records = cursor.fetchmany(2)
    for row in mobile_records:
        print("Id =", row[0])
        print("Модель =", row[1])
        print("Цена =", row[2], "\n")

    print("Вывод следующих двух строк")
    mobile_records = cursor.fetchmany(2)
    for row in mobile_records:
        print("Id =", row[0])
        print("Модель =", row[1])
        print("Цена =", row[2], "\n")

except (Exception, Error) as error:
    print("Ошибка при работе с PostgreSQL", error)
finally:
    if connection:
        cursor.close()
        connection.close()
        print("Соединение с PostgreSQL закрыто")