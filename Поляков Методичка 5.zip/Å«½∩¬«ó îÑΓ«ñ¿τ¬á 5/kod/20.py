import psycopg2
from psycopg2 import Error

try:
    connection = psycopg2.connect(
        user="postgres",
        password="1111",
        host="127.0.0.1",
        port="5432",
        database="postgres_db"
    )
    connection.autocommit = False
    cursor = connection.cursor()
    amount = 200

    cursor.execute("SELECT price FROM mobile WHERE id = 1")
    price_a = int(cursor.fetchone()[0]) - amount
    cursor.execute("UPDATE mobile SET price = %s WHERE id = 1", (price_a,))

    cursor.execute("SELECT price FROM mobile WHERE id = 2")
    price_b = int(cursor.fetchone()[0]) + amount
    cursor.execute("UPDATE mobile SET price = %s WHERE id = 2", (price_b,))

    connection.commit()
    print("Транзакция успешно завершена")

except (Exception, Error) as error:
    print("Ошибка в транзакции. Отмена всех операций", error)
    connection.rollback()
finally:
    if connection:
        cursor.close()
        connection.close()
        print("Соединение с PostgreSQL закрыто")