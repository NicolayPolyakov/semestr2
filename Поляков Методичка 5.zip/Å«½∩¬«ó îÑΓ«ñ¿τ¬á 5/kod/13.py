import psycopg2
from psycopg2 import Error

def update_table(mobile_id, price):
    try:
        connection = psycopg2.connect(
            user="postgres",
            password="1111",
            host="127.0.0.1",
            port="5432",
            database="postgres_db"
        )
        cursor = connection.cursor()
        
        print("Таблица до обновления записи")
        cursor.execute("SELECT * FROM mobile WHERE id = %s", (mobile_id,))
        print(cursor.fetchone())

        cursor.execute(
            "UPDATE mobile SET price = %s WHERE id = %s",
            (price, mobile_id)
        )
        connection.commit()
        print(cursor.rowcount, "Запись успешно обновлена")

        print("Таблица после обновления записи")
        cursor.execute("SELECT * FROM mobile WHERE id = %s", (mobile_id,))
        print(cursor.fetchone())

    except (Exception, Error) as error:
        print("Ошибка при работе с PostgreSQL", error)
    finally:
        if connection:
            cursor.close()
            connection.close()
            print("Соединение с PostgreSQL закрыто")

update_table(3, 970)