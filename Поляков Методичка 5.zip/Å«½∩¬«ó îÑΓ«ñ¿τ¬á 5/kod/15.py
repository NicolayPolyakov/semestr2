import psycopg2
from psycopg2 import Error

def bulk_insert(records):
    try:
        connection = psycopg2.connect(
            user="postgres",
            password="1111",
            host="127.0.0.1",
            port="5432",
            database="postgres_db"
        )
        cursor = connection.cursor()
        
        cursor.executemany(
            "INSERT INTO mobile (id, model, price) VALUES (%s,%s,%s)",
            records
        )
        connection.commit()
        print(cursor.rowcount, "Записи успешно вставлены в таблицу mobile")

    except (Exception, Error) as error:
        print("Ошибка при работе с PostgreSQL", error)
    finally:
        if connection:
            cursor.close()
            connection.close()
            print("Соединение с PostgreSQL закрыто")

records_to_insert = [(4,'LG', 800), (5,'One Plus 6', 950)]
bulk_insert(records_to_insert)